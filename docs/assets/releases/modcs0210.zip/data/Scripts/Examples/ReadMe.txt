This folder contains a few examples using the ModCS Lua API.
Most of them are meant to be modified and exist for the educational purposes.
They are free to use and do not require any credit to be given.